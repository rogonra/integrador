
package com.proyecto.app.Service;

import com.proyecto.app.Entity.Persona;
import com.proyecto.app.Interface.IPersonaService;
import com.proyecto.app.Repository.IPersonaRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ImpPersonaService implements IPersonaService {
    @Autowired private IPersonaRepository ipersonaRepository;
  
    @Override
    public List<Persona> getPersona() {
       List<Persona> persona = getIpersonaRepository().findAll();
       return persona;
    }
    @Override
      public void savePersona(Persona persona) {
        getIpersonaRepository().save(persona);
    }
     @Override
    public void deletePersona(Long id) {
        getIpersonaRepository().deleteById(id);
    }
    @Override
    public Persona findPersona(Long id) {
       Persona persona = getIpersonaRepository().findById(id).orElse(null);
       return persona;
    }
     public IPersonaRepository getIpersonaRepository() {
        return ipersonaRepository;
    }

    public void setIpersonaRepository(IPersonaRepository ipersonaRepository) {
        this.ipersonaRepository = ipersonaRepository;
    }
    
}
